import Inventory from "./inventory.mjs";

// Example usage
 const inventory = new Inventory();
  
// Adding items to the inventory
inventory.addItem("Laptop", "Electronics", 10);
inventory.addItem("Chair", "Furniture", 20);
inventory.addItem("Pen", "Stationery", 100);

// Updating the quantity of an item
inventory.updateQuantity("Laptop", 15);

// Removing an item from the inventory
inventory.removeItem("Chair");

// Searching for items by name
console.log(inventory.searchByName("Laptop"));

// Searching for items by category
console.log(inventory.searchByCategory("Stationery"));

// Generating an inventory report
console.log("Inventory Report:");
console.log(inventory.generateReport());