// Define the Inventory class
class Inventory {
  // the constructor initialzes an empty array to store items
    constructor() {
       this.items = [];//intialize an empty array to hold inventory class
    }
  
    // Method to add a new item
    addItem(name, category, quantity) {
      // Adds a new item to the inventory by pushing an object with name, category, and quantity to the items array.
      const item = { 
        name: name,
        category: category,
        quantity: quantity
      };
      this.items.push(item);//adds the new item object to the items of array
      console.log(`Added:${name} to the inventory.`);
    }
  
    // Method to update item quantity
    // Updates the quantity of an existing item in the inventory. If the item does not exist, it returns an error message.
    updateQuantity(name, newQuantity) {
      // find the item in the array and it will provided name
      const item = this.items.find(item => item.name === name);
      // if the item was found,it will update its quantity
      if (item) { 
        item.quantity = newQuantity; // item quantity with the new value
        console.log(`Updated quantity of ${name} to ${newQuantity}.`);
      } else {
        console.log(`${name} not found in the inventory.`);
      }
    }
  
    // Method to remove an item
    // Removes an item from the inventory based on its name. If the item is not found, an error message is returned
    removeItem(name) {
      const index = this.items.findIndex(item => item.name === name);
      // if the item was found remove it from the array
      if (index !== -1) {
        this.items.splice(index, 1);// remove the item from the array from the index 
        console.log(`Removed ${name} from the inventory.`);
      } else {
        console.log(`${name} not found in the inventory.`);
      }
    }
  
    // Method to search for items by name
    // Searches the items array for an item that matches the given name using the filter() method.
    searchByName(name) {
      // by using the filter method to find all items so that will provided name
      const foundItems = this.items.filter(item => item.name === name);
      // if match items are found,return or return a message item were not found
      return foundItems.length ? foundItems : `${name} not found in the inventory.`;
    }
  
    // Method to search for items by category
    // Similar to searchByName(), but it filters by category
    searchByCategory(category) {
      // by using the filter method to find all items so that will provided category
      const foundItems = this.items.filter(item => item.category === category);
      // if match items are found,return or return a message item were not found
      return foundItems.length ? foundItems : `No items found in category: ${category}`;
    }
  
    // Method to generate an inventory report
    // Generates a summary report of all items in the inventory, including their names and quantities, using map()
    generateReport() {
      return this.items.map(item => `${item.name} (Category: ${item.category}) - Quantity: ${item.quantity}`).join('\n');
    }
  }
  // Exports the Inventory class so that it can be imported and used in other files.
  export default Inventory;
  
  // Example usage
  // const inventory = new Inventory();
  
  